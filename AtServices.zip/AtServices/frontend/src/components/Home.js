import React from "react";

const Home = () => {
  return <div>This is a Home Page</div>;
};

export default Home;
